# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 14:19:08 2019

@author: carlson
"""
import numpy as np
import mxnet as mx
from mxnet import gluon,autograd
from gluoncv.utils import makedirs, TrainingHistory
import time, datetime
import argparse,logging

from process import showprocess
from get_h5 import write_csv, h5_readdata
from resnet import get_resnet
#from resnet_gelu import get_resnet_gelu as get_resnet
from resnext import get_resnext
#from resnext_gelu import get_resnext_gelu as get_resnext
#from inception import get_inception_v3
from densenet import get_densenet
from resnest import get_resnest

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger()

now = datetime.datetime.now()
otherStyleTime = now.strftime("%Y%m%d_%H.%M")
pprint = logger.info


net_dic={'rt_18_v1', 'rt_34_v1', 'rt_50_v1', 
         'rt_18_v2', 'rt_34_v2', 'rt_50_v2',
         'rxt_18', 'rxt_34', 'rxt_50',
         'rxte_34', 'rxte_50',
         'serxt_34', 'serxt_50','serxt_101',
         'serxt64_34', 'serxt64_50','serxt64_101',
         'dnt_18', 'dnt_34', 'dnt_50',
         'rst_14','rst_26','rst_50','rst_101','rst_200','rst_269'
        #'rxtnet':get_rxtnet()
}

def normalization(ndata):
    # range(0,1)
    _range = np.max(ndata) - np.min(ndata)
    return (ndata - np.min(ndata)) / _range

def get_cwnet(name=None, ctx=None, classes=None, input_size=(224,224),pretrained=False, modelpath='./model/xxx.params',istrain=True):
    if name in net_dic:
        nameinfo = name.split('_')
        pprint('get model is %s'%(name))
        if nameinfo[0] == 'rt':
            num_layers = int(nameinfo[1])
            ver = 1 if nameinfo[2]=='v1' else 2
            net=get_resnet(ver, num_layers, ctx=ctx, classes=classes, pretrained=pretrained, modelpath=modelpath)
        elif nameinfo[0] == 'rxt':
            num_layers = int(nameinfo[1])
            net=get_resnext(num_layers, ctx=ctx, classes=classes, pretrained=pretrained, modelpath=modelpath)
        elif nameinfo[0] == 'rxte':
            num_layers = int(nameinfo[1])
            net=get_resnext(num_layers, ctx=ctx, classes=classes, pretrained=pretrained, modelpath=modelpath, use_se=True)
        elif nameinfo[0] == 'serxt':
            num_layers = int(nameinfo[1])
            net=get_resnext(num_layers, ctx=ctx, classes=classes, pretrained=pretrained, modelpath=modelpath, use_se=True, deep_stem=True, avg_down=True)
        elif nameinfo[0] == 'serxt64':
            num_layers = int(nameinfo[1])
            net=get_resnext(num_layers, ctx=ctx, classes=classes, pretrained=pretrained, modelpath=modelpath, cardinality=64, use_se=True, deep_stem=True, avg_down=True)        
        elif nameinfo[0] == 'dnt':
            num_layers = int(nameinfo[1])
            net=get_densenet(num_layers, ctx=ctx, classes=classes, pretrained=pretrained, modelpath=modelpath)
        elif nameinfo[0] == 'rst':
            num_layers = int(nameinfo[1])
            net = get_resnest(num_layers,ctx=ctx, classes=classes,input_size=input_size, pretrained=pretrained, modelpath=modelpath)
        else:
            pprint('error!!!, model name error')
            return -1
        if istrain and not pretrained:
            net.initialize(mx.init.Xavier(), ctx = ctx)
        
        logger.addHandler(logging.FileHandler('./model/%s_ad3d_%s.log'%(name,otherStyleTime), 'a'))
        pprint(net)
        return net
        
    else:
        print('------------- please follow name: ----------------')
        print(net_dic)
    return -1


#Define our trainer for net
def train(net, train_iter, test_iter, epochs=30, 
          device_batch_size=16, lr = 0.1, lr_decay= 0.1, ctx=None, 
          modelname='model_name', savepath='./model/', thresh = 0.7):
    
    optimizer_params = {'learning_rate': lr, 'wd': 0.0001,
                        #'momentum': 0.9
                        }
    num_workers = 8
    batch_size = device_batch_size * len(ctx)
    # Epochs where learning rate decays 
    lr_decay_epoch = [int(epochs*0.4), int(epochs*0.5), int(epochs*0.6),int(epochs*0.8), np.inf]
    lr_decay_count = 0

    train_metric = mx.metric.Accuracy()
    train_history = TrainingHistory(['training-error', 'validation-error'])
    
    #trainer = gluon.Trainer(net.collect_params(), 'nag', optimizer_params)
    trainer = gluon.Trainer(net.collect_params(), 'adam', optimizer_params)
    loss_fn = gluon.loss.SoftmaxCrossEntropyLoss()
    
    pprint('training on %s'%(str(ctx)))
    process_bar = showprocess(len(train_iter), modelname +' OK!')
    pprint('lr=%f  lr_decay=%f  batch_size=%d'%(lr,lr_decay,batch_size))
    flag_save, model_cnt = 12, 2
    for epoch in range(epochs):
        tic = time.time()
        train_metric.reset()
        train_loss = 0

        # Learning rate decay
        if epoch == lr_decay_epoch[lr_decay_count]:
            trainer.set_learning_rate(trainer.learning_rate*lr_decay)
            lr_decay_count += 1

        # Loop through each batch of training data
        for i, batch in enumerate(train_iter):
            # Extract data and label
            data = gluon.utils.split_and_load(batch[0], ctx_list=ctx, batch_axis=0)
            label = gluon.utils.split_and_load(batch[1], ctx_list=ctx, batch_axis=0)

            # AutoGrad
            with autograd.record():
                output = [net(X) for X in data]
                loss = [loss_fn(yhat, y) for yhat, y in zip(output, label)]

            # Backpropagation
            autograd.backward(loss)

            # Optimize
            trainer.step(batch_size)

            # Update metrics
            train_loss += sum([l.sum().asscalar() for l in loss])
            train_metric.update(label, output)
            
            process_bar.show_process()

        name, acc = train_metric.get()
        # Evaluate on Validation data
        name, val_acc = test(net, test_iter, ctx)

        # Update history and print metrics
        train_history.update([1-acc, 1-val_acc])
        pprint('[%s]  Epoch=%d/%d,  train=%f,  val=%f,  loss=%f,  time: %f' %
            (modelname, epoch,epochs, acc, val_acc, train_loss, time.time()-tic))
        
        # Save model
        if acc >= thresh:
            if val_acc >= thresh :
                flag_save -=1
                if flag_save<=0:
                    net.save_parameters(savepath+'%s_ad3d_%d_%.2f.params'%(modelname,epoch,val_acc))
                    model_cnt -=1
            else:
                flag_save = 10
            
        if model_cnt<0: break 
            
    net.save_parameters(savepath+'%s_ad3d_%d_%.2f.params'%(modelname,epochs,val_acc))
        
    # We can plot the metric scores with:
    # train_history.plot()

def test(net=None, val_data=None, ctx=None):
    metric = mx.metric.Accuracy()
    for i, batch in enumerate(val_data):
        data = gluon.utils.split_and_load(batch[0], ctx_list=ctx, batch_axis=0)
        label = gluon.utils.split_and_load(batch[1], ctx_list=ctx, batch_axis=0)
        outputs = [net(X) for X in data]
        metric.update(label, outputs)
    return metric.get()

def test_to_csv(test_h5s=['testa','testb'], testmodel=[{'name':'rt_18_v1', 'tmpath':'./model/xxx.params','thr':0.7}], classes=3, ctx=None):
    # Test starting 
    print('testing on %s'%(ctx))
    test_result = {'test':[]}
    for index, model in enumerate(testmodel):
        # get adnet
        #t_net = get_adnet(name= model['name'], ctx=ctx, classes=classes, pretrained=True, modelpath=model['modelpath'], istrain=False)
        key = model['name']+'_'+str(index)
        test_result[key]=[]
    
    # Load testing data
    all_test_data = []
    for testname in test_h5s:
        h5data = h5_readdata(testname)
        for indx, per_h5data in enumerate(h5data):
            dataname = testname.split('/')[-1][:-3]+'_'+str(indx)
            _data = mx.nd.array([normalization(per_h5data)])
            all_test_data.append({'name':dataname,'data':_data})
    
    # testing
    for index, model in enumerate(testmodel):
        # get adnet
        t_net = get_adnet(name= model['name'], ctx=ctx, classes=classes, pretrained=True, modelpath=model['tmpath'], istrain=False)
        key = model['name']+'_'+str(index)
        #test_result[key]=[]
        for indx, h5_data in enumerate(all_test_data):
            _data = h5_data['data']
            data = _data.as_in_context(ctx[0])
            pre_info = t_net.forward(data)
            pre_y = pre_info.argmax(axis=1)
            pre_ys = str(int(pre_y.asnumpy()[0]))
            pre_ys_acc = pre_info.asnumpy()[0]
            
            print(key+': '+h5_data['name']+' = ' + pre_ys + ', prob = %.4f, %.4f, %.4f'%(pre_ys_acc[0],pre_ys_acc[1],pre_ys_acc[2]))
            test_result[key].append({'testa_id':h5_data['name'],'label':pre_ys,'prob':pre_ys_acc})
    test_result.pop('test')
    
    keys = list(test_result.keys())
    result_data=[]
    for indx in range(len(all_test_data)):
        label_data = []
        for key in keys:
            label_name = test_result[key][indx]['testa_id']
            label_data = label_data + list(test_result[key][indx]['prob'])
        
        result_data.append({'testa_id':label_name,'probs':mx.nd.array(label_data)})

    all_result=[]
    out_result=[]
    keys = list(test_result.keys())
    for idx in range(len(test_result[keys[0]])):
        
        hline={'testa_id': test_result[keys[0]][idx]['testa_id']}
        val ={'0':0, '1':0, '2':0}
        for key in keys:
            #hline = {'testa'+'_id':testname+'_'+str(indx)}
            if hline['testa_id']==test_result[key][idx]['testa_id']:
                hline[key] = test_result[key][idx]['label']
            else:
                hline[key] = -1
            val[hline[key]]= val[hline[key]]+1
        
        hline['label']=max(val, key=val.get)
        
        all_result.append(hline)
        out_result.append({'testa_id':hline['testa_id'], 'label':hline['label']})
        #print(hline)
    #print(all_result)
    #test_result.append({'testa'+'_id':testname+'_'+str(indx),'label':pre_ys})
    now = datetime.datetime.now()
    csvnames= test_h5s[0].split('/')[-1][:-3]+test_h5s[1].split('/')[-1][:-3]
    otherStyleTime = now.strftime("%Y%m%d_%H.%M")    
    write_csv(all_result,test_name='./output/ad_all_%s'%csvnames+otherStyleTime,labels=list(all_result[0].keys()))
    write_csv(out_result,test_name='./output/ad_result_%s'%csvnames+otherStyleTime,labels=list(out_result[0].keys()))
    
    return result_data,out_result