# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 14:19:08 2019

@author: carlson
"""

import os
import sys
os.environ['PYTHONUNBUFFERED'] = '1'
os.environ['MXNET_CUDNN_AUTOTUNE_DEFAULT'] = '0'
os.environ['MXNET_ENABLE_GPU_P2P'] = '0'
this_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(this_dir, 'func'))
sys.path.insert(0, os.path.join(this_dir, 'config'))

import mxnet as mx
import numpy as np
import time
from mxnet import gluon, autograd, init
from mxnet import ndarray as nd
from gluoncv.utils import makedirs, TrainingHistory
from mult_class_evaluation import evaluations
from get_data_list import load_img_data
from multi_net import get_cwnet
from process import showprocess

import logging
logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger()
pprint = logger.info

def try_gpu(n):
   try:
        ctx = [mx.gpu(i) for i in range(n)]
        #_ = nd.array([0], ctx=ctx)
   except mx.base.MXNetError:
        ctx = mx.cpu()
   return ctx

#ctx =[mx.gpu(0),mx.gpu(1)]
ctx = [mx.gpu(0)]

def test(net=None, val_data=None, ctx=None):
    metric = mx.metric.Accuracy()
    for i, batch in enumerate(val_data):
        data = gluon.utils.split_and_load(batch[0], ctx_list=ctx, batch_axis=0)
        label = gluon.utils.split_and_load(batch[1], ctx_list=ctx, batch_axis=0)
        outputs = [net(X) for X in data]
        metric.update(label, outputs)
    return metric.get()

def train(net, train_iter, test_iter, epochs=30, 
          device_batch_size=16, lr = 0.1, lr_decay= 0.1, ctx=None, 
          modelname='model_name', savepath='./model/', thresh = 0.7):
    
    optimizer_params = {'learning_rate': lr, 'wd': 0.0001,
                        #'momentum': 0.9
                        }
    
    batch_size = device_batch_size * len(ctx)
    
    # Epochs where learning rate decays 
    lr_decay_epoch = [int(epochs*0.4), int(epochs*0.5), int(epochs*0.6),int(epochs*0.8), np.inf]
    lr_decay_count = 0

    train_metric = mx.metric.Accuracy()
    train_history = TrainingHistory(['training-error', 'validation-error'])
    
    #trainer = gluon.Trainer(net.collect_params(), 'nag', optimizer_params)
    trainer = gluon.Trainer(net.collect_params(), 'adam', optimizer_params)
    loss_fn = gluon.loss.SoftmaxCrossEntropyLoss()
    #loss_fn = gluon.loss.
    
    pprint('training on %s'%(str(ctx)))
    process_bar = showprocess(len(train_iter), modelname +' OK!')
    pprint('lr=%f  lr_decay=%f  batch_size=%d'%(lr,lr_decay,batch_size))
    flag_save, model_cnt = 12, 2
    for epoch in range(epochs):
        tic = time.time()
        train_metric.reset()
        train_loss = 0

        # Learning rate decay
        if epoch == lr_decay_epoch[lr_decay_count]:
            trainer.set_learning_rate(trainer.learning_rate*lr_decay)
            lr_decay_count += 1

        # Loop through each batch of training data
        for i, batch in enumerate(train_iter):
            # Extract data and label
            data = gluon.utils.split_and_load(batch[0], ctx_list=ctx, batch_axis=0)
            label = gluon.utils.split_and_load(batch[1], ctx_list=ctx, batch_axis=0)

            # AutoGrad
            with autograd.record():
                output = [net(X) for X in data]
                loss = [loss_fn(yhat, y) for yhat, y in zip(output, label)]

            # Backpropagation
            autograd.backward(loss)

            # Optimize
            trainer.step(batch_size)

            # Update metrics
            train_loss += sum([l.sum().asscalar() for l in loss])
            train_metric.update(label, output)
            
            process_bar.show_process()

        name, acc = train_metric.get()
        # Evaluate on Validation data
        name, val_acc = test(net, test_iter, ctx)

        # Update history and print metrics
        train_history.update([1-acc, 1-val_acc])
        pprint('   [%s]  Epoch=%d/%d,  train=%f,  val=%f,  loss=%f,  time: %f' %
            (modelname, epoch,epochs, acc, val_acc, train_loss, time.time()-tic))
        
        # Save model
        if acc >= thresh:
            if val_acc >= thresh :
                flag_save -=1
                if flag_save<=0:
                    net.save_parameters(savepath+'%s_%d_%.2f.params'%(modelname,epoch,val_acc))
                    model_cnt -=1
            else:
                flag_save = 10
            
        if model_cnt<0: break 
            
    net.save_parameters(savepath+'%s_%d_%.2f.params'%(modelname,epochs,val_acc))




# load training dataset
classname =['1','2','3']
epochs = 100
input_imgsize=(300, 350)
modelinfos=[
            #0
            {'name':'rst_14', 'batch_size':5, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rst_14_0.params', 'thr':0.75},
            #1
            {'name':'rst_26', 'batch_size':5, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rst_26_0.params', 'thr':0.75},
            #2
            {'name':'rst_50', 'batch_size':5, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rst_50_0.params', 'thr':0.75},
            #3
            {'name':'rst_101', 'batch_size':5, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rst_101_0.params', 'thr':0.75},
            #4
            {'name':'rst_200', 'batch_size':5, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rst_200_0.params', 'thr':0.75},
            #5
            {'name':'rst_269', 'batch_size':5, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rst_269_0.params', 'thr':0.75},
            #6
            {'name':'rxt_34', 'batch_size':16, 'lr':0.0001, 'thresh':1, 'pretrained':True, 'tmpath':'./model/rxt_34_ad3d_0.params', 'thr':0.7},
            #7
            {'name':'rxt_50', 'batch_size':5, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rst_50_0.params', 'thr':0.75},
            #8
            {'name':'rxt_101', 'batch_size':5, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rst_101_0.params', 'thr':0.75},
            #9
            {'name':'rxt_200', 'batch_size':5, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rst_200_0.params', 'thr':0.75},
            #10
            {'name':'rxt_269', 'batch_size':5, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rst_269_0.params', 'thr':0.75},
            #11
            {'name':'rt_50_v1', 'batch_size':24, 'lr':0.01, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rt_50_v1_ad3d_0.params', 'thr':0.7},
            #12
            {'name':'rt_50_v2', 'batch_size':18, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rt_50_v2_ad3d_0.params', 'thr':0.7},            
            #13
            {'name':'rxte_34', 'batch_size':16, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rxte_34_ad3d_0.params', 'thr':0.7},
            #14
            {'name':'rxte_50', 'batch_size':12, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/rxte_50_ad3d_0.params', 'thr':0.7},
            #15
            {'name':'serxt_34', 'batch_size':12, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/serxt_34_ad3d_0.params', 'thr':0.7},
            #16
            {'name':'serxt_50', 'batch_size':12, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/serxt_50_ad3d_0.params', 'thr':0.7},
            #17
            {'name':'dnt_18', 'batch_size':16, 'lr':0.01, 'thresh':1, 'pretrained':False, 'tmpath':'./model/dnt_18_ad3d_0.params', 'thr':0.7},
            #18
            {'name':'dnt_34', 'batch_size':8, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/dnt_34_ad3d_0.params', 'thr':0.7},
            #19
            {'name':'dnt_50', 'batch_size':8, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/dnt_50_ad3d_0.params', 'thr':0.7},
            #20
            {'name':'serxt64_50', 'batch_size':4, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/serxt64_50_ad3d_0.params', 'thr':0.7},
            #21
            {'name':'serxt64_101', 'batch_size':4, 'lr':0.0001, 'thresh':1, 'pretrained':False, 'tmpath':'./model/serxt64_101_ad3d_0.params', 'thr':0.7}            
            ]


#istrain = False

net_indx = [7]
istrain = True
first_data = 0
if istrain:
    
    # training multi-model
    for indx in net_indx:
        modelinfo=modelinfos[indx]
        
        # loading dataset
        if first_data == 0:
            
            train_list = 'G:/ChiYuTing/data/test.lst'
            train_iter = load_img_data(train_list, modelinfo['batch_size'],resize=input_imgsize) 
            val_list = 'G:/ChiYuTing/data/val.lst'
            val_iter = load_img_data(val_list,modelinfo['batch_size'],resize=input_imgsize) 
            #test_list = 'G:/ChiYuTing/data/test.lst'
            #test_iter = load_img_data(test_list,modelinfo['batch_size'],resize=input_imgsize)
            first_data = 1

        net = None
        net = get_cwnet(name=modelinfo['name'], classes=len(classname), input_size=input_imgsize, ctx=ctx, 
                        pretrained=modelinfo['pretrained'], modelpath=modelinfo['tmpath'])
        print(net)
        train(net, train_iter, val_iter, epochs=epochs, device_batch_size=modelinfo['batch_size'], 
              lr=modelinfo['lr'], lr_decay= 0.1, ctx=ctx, modelname=modelinfo['name'],thresh=modelinfo['thresh'])
        
'''


#classname =['0','1','2']
#evals = evaluations(test_result['label'],test_gt['label'],classname)
# plot_network
#net.hybridize()
#net.collect_params().initialize()
#x = mx.sym.var('data')
#sym = net(x)
#mx.viz.plot_network(sym)

'''