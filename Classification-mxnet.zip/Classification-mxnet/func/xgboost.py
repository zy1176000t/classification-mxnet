# -*- coding: utf-8 -*-
"""
Created on Thu Nov 21 16:32:54 2019

@author: carlson
"""
# 导入mxnet
import random
import mxnet as mx
import numpy as np

# 导入mxnet的gluon, ndarray, autograd
from mxnet import gluon
from mxnet import autograd
from mxnet import ndarray as nd
x=[]
y=[]
for indx, res_data in enumerate(result_data): 
    x.append(res_data['probs'].asnumpy())
    y.append(int(out_result[indx]['label']))

_x= nd.array(x)
_y= nd.array(y)

batch_size = 10
dataset = gluon.data.ArrayDataset(_x, _y)
data_iter = gluon.data.DataLoader(dataset, batch_size, shuffle=True)
net = gluon.nn.Sequential()
net.add(gluon.nn.Dense(10))
net.add(gluon.nn.Dense(3))
net.initialize()
square_loss = gluon.loss.SoftmaxCrossEntropyLoss()
trainer = gluon.Trainer(net.collect_params(), 'adam', 
                        {'learning_rate': 0.001})
print(net)

epochs = 1000
for epoch in range(epochs):
    # 总的loss
    total_loss = 0
    for data, label in data_iter:
        # 记录梯度
        with autograd.record():
            # 计算预测值
            output = net(data)
            # 计算loss
            loss = square_loss(output, label)
        # 根据loss进行反向传播计算梯度
        loss.backward()
        # 更新权重, batch_size用来进行梯度平均
        trainer.step(batch_size)
        # 计算总的loss
        total_loss += nd.sum(loss).asscalar()  
    print ("Epoch %d, average loss: %f" % (epoch, total_loss/232))
net.save_parameters('./xgboost.params')