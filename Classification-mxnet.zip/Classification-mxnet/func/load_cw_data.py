# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 14:19:08 2019

@author: carlson
"""
import sys
import os
import mxnet as mx
import numpy as np
import cv2 as cv
from mxnet.gluon import data as gdata



def normalization(ndata):
    # range(0,1)
    _range = np.max(ndata) - np.min(ndata)
    return (ndata - np.min(ndata)) / _range

def GaussianNoise(data,means,sigma,percent): #data[79,95,79]
    noise = np.random.normal(means,sigma,data.shape)
    _range = np.max(noise) - np.min(noise)
    return data+percent*(noise - np.min(noise))/_range
    
def listDir(path, list_name):
    """

    :param path: 路径
    :param list_name: path下所有文件的绝对路径名的列表
    :return:
    """
    for file in os.listdir(path):
        file_path = os.path.join(path, file)
        if os.path.isdir(file_path):
            listDir(file_path, list_name)
        else:
            list_name.append(file_path)

def load_ad3d_data(resize=None, img_folder='./../data/train/', img_labels=['1','2','3'], batch_size=20,  isDataLoader=False):
    train_cw_data =[]
    train_label ={'id':[],'label':[]}
    for img_label in img_labels:
        img_path = img_folder + img_label +'/'
        imgnames = []
        listDir(img_path,imgnames)
        for indx, imgname in enumerate(imgnames):
            print(imgname)
            #img = cv.imread(imgname)
            #train_cw_data = train_cw_data + [normalization(x) for x in img]
            #train_label['id'].append(indx)
            #train_label['label'].append(img_labels)
    
    #train_data = mx.gluon.data.ArrayDataset(mx.nd.array(train_ad3d_data), mx.nd.array(train_label['label']))
    return imgnames   
        
        
'''      
        train_ad3d_data = train_ad3d_data + [normalization(x) for x in h5_data]
        h5_label = h5_leableget(per_train_h5[:-8]+'_label.csv')
        train_label['id'] = train_label['id'] +h5_label['id']
        train_label['label'] = train_label['label'] + h5_label['label']
        print('loading train dataset: ',per_train_h5)

    test_ad3d_data = [] #h5_readdata(test_h5)
    test_label = test_label ={'id':[],'label':[]}
    #h5_leableget(test_h5[:-8]+'_label.csv')
    for per_test_h5 in test_h5:
        h5_data = h5_readdata(per_test_h5)
        test_ad3d_data = test_ad3d_data + [normalization(x) for x in h5_data]
        h5_label = h5_leableget(per_test_h5[:-8]+'_label.csv')
        test_label['id'] = test_label['id'] +h5_label['id']
        test_label['label'] = test_label['label'] + h5_label['label']    
        print('loading test dataset: ',per_test_h5)
        
    train_data = mx.gluon.data.ArrayDataset(mx.nd.array(train_ad3d_data), mx.nd.array(train_label['label']))
    test_data = mx.gluon.data.ArrayDataset(mx.nd.array(test_ad3d_data), mx.nd.array(test_label['label']))

    if isDataLoader:
        num_workers = 0 if sys.platform.startswith('win32') else 4
        train_iter = gdata.DataLoader(train_data, batch_size, shuffle=True,
                                      num_workers=num_workers)
        test_iter = gdata.DataLoader(test_data, batch_size, shuffle=False,
                                     num_workers=num_workers)
        return train_iter, test_iter 
    else:
        return train_data, test_data
'''

def reload_ad3d_data(train_data, test_data, batch_size):
    num_workers = 0 if sys.platform.startswith('win32') else 4

    train_iter = gdata.DataLoader(train_data, batch_size, shuffle=True,
                                  num_workers=num_workers)
    test_iter = gdata.DataLoader(test_data, batch_size, shuffle=False,
                                 num_workers=num_workers)
    
    return train_iter, test_iter 


images = load_ad3d_data(resize=None, img_folder='./../data/train/', img_labels=['1','2','3'])
