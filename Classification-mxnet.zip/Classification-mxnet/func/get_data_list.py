# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 14:19:08 2019

@author: carlson
"""

import os
import random
import mxnet as mx
import numpy as np
import cv2
import sys
#import gluon
from mxnet.gluon.data.vision import transforms
from mxnet.gluon import data as gdata

def load_data(data_list, batch_size = 10, data_shape=(3, 224, 224)):
    data_iter = None
    data_iter = mx.io.ImageRecordIter(batch_size = batch_size, 
    							  resize=30,
    							  data_shape=data_shape,# depth,height,width
                                  path_imgrec=data_list.split('.')[0]+'.rec',
                                  path_imgidx=data_list.split('.')[0]+'.idx' )
    '''
    data_iter.reset()
    batch = data_iter.next()
    data = batch.data[0]
    for i in range(batch_size):
        plt.subplot(1,batch_size,i+1)
        plt.imshow(data[i].asnumpy().astype(np.uint8).transpose((1,2,0)))
    plt.show()
    '''
    return data_iter

def normalization(ndata):
    # range(0,1)
    _range = np.max(ndata) - np.min(ndata)
    return (ndata - np.min(ndata)) / _range

def load_img_data(data_list, batch_size = 10, resize=(300, 350), isDataLoader=True): ##resize=(224, 224)
    data_iter = None
    img_data={'indx':[],'data':[], 'label':[]}
    with open(data_list) as f:
        flines = f.readlines()
        for line in flines:
            infos = line.split('\t')
            indx = infos[0]
            label = infos[1]
            fullpath = infos[2][:-1]
            print(fullpath, label)
            color = 0 # choices=[-1, 0, 1]
            img=None
            try:
                #img = cv2.imread(fullpath, args.color)
                img = cv2.imdecode(np.fromfile(fullpath,dtype=np.uint8),color) # choices=[-1, 0, 1]
            except:
                print('imread error trying to load file: %s ' % fullpath)
                return            
            if img is None:
                print('imread read blank (None) image for file: %s' % fullpath)
                return
            
            img = cv2.resize(img, resize)
            img = img.astype(np.float32)/255
            if color==0:
                #img1 = img.transpose(2,0,1)
                img = img.transpose(1,0)
                img1 =img[np.newaxis,:,:]
                #img = mx.nd.array(img)
                #img = mx.nd.transpose(img, axes=(2,0,1))
                #img1 = mx.nd.expand_dims(img, axis=0)
            else:
                img1 = img.transpose(2,0,1)
                #img1 =img[np.newaxis,:,:]
        
            img_data['indx'] = img_data['indx'] + [indx]
            img_data['data'] = img_data['data'] + [img1]
            img_data['label'] = img_data['label'] + [label]
                    
    t_data = mx.gluon.data.ArrayDataset(mx.nd.array(img_data['data']), mx.nd.array(img_data['label']))     
        
    if isDataLoader:
        num_workers = 0 if sys.platform.startswith('win32') else 4
        data_iter = gdata.DataLoader(t_data, batch_size, shuffle=True,
                                      num_workers=num_workers)
        return data_iter
    else:
        return img_data['data']


def get_data_list(img_path, classes=['1','2'], ratio=[2,2,1]):
    #ratio=[train, val, test]
    txtsavepath=img_path[:-len(img_path.split('/')[-1])]
    trainval_percent=0.95  # trainval占整个数据集的百分比，剩下部分就是test所占百分比  
    train_percent=0.8  # train占trainval的百分比，剩下部分就是val所占百分比 

    ftrainval=open(txtsavepath +'trainval.lst','w')  
    ftest=open(txtsavepath +'test.lst','w')
    ftrain=open(txtsavepath +'train.lst','w')  
    fval=open(txtsavepath +'val.lst','w')
    nums = 0
    for c_name in classes:
        c_path = img_path + '/'+ c_name
        all_img_name = os.listdir(c_path)
        #for img_name in all_img_name:
        #    img_pt = os.path.join(c_path, all_img_name[indx-1])
        num_img = len(all_img_name)
        trainval = sorted(random.sample(range(1, num_img+1),int(num_img*trainval_percent)),reverse=False)
        test = sorted(list(set(range(1, num_img+1)).difference(set(trainval))),reverse=False)
        trainvalsize=len(trainval)
        train = sorted([trainval[i-1] for i in random.sample(range(1,trainvalsize+1),int(trainvalsize*train_percent))])
        val = sorted(list(set(trainval).difference(set(train))))
        
        for indx in range(1,num_img+1):       
            if indx in set(trainval):
                ftrainval.write('{idx}\t{label}\t{img_name}\n'.format(idx=indx+nums,label=c_name,img_name=c_path+'/'+all_img_name[indx-1])) #写入
                if indx in set(train):
                    ftrain.write('{idx}\t{label}\t{img_name}\n'.format(idx=indx+nums,label=c_name,img_name=c_path+'/'+all_img_name[indx-1])) # 写入
                else:
                    fval.write('{idx}\t{label}\t{img_name}\n'.format(idx=indx+nums,label=c_name,img_name=c_path+'/'+all_img_name[indx-1]))  # 写入
            else:
                ftest.write('{idx}\t{label}\t{img_name}\n'.format(idx=indx+nums,label=c_name,img_name=c_path+'/'+all_img_name[indx-1])) # 写入
        nums = nums+num_img
    
    ftrainval.close()
    ftest.close()
    ftrain.close()
    fval.close()

 
#DataPath = 'G:/ChiYuTing/data/train'
#Classnames = ['1','2','3']
#get_data_list(DataPath, Classnames)

#train_list = 'G:/ChiYuTing/data/test.lst'
#train_iter= load_img_data(train_list, isDataLoader=True)
