# -*- coding: utf-8 -*-
"""
Created on Mon Jun 22 12:29:43 2020

@author: carlson
"""

import os
from PIL import Image, ImageFilter
import random

def modify_file_path(file_path, middle_name):
    # file_path = "D:/test/test.jpy"
    # middle_name = '_mask'
    (filepath, tempfilename) = os.path.split(file_path)
    # print(filepath,tempfilename)
    (filename, extension) = os.path.splitext(tempfilename)
    # print(filename,extension)
    filename = filename + '_' + middle_name + extension
    file_path = os.path.join(filepath, filename)
    # file_path = 'D:/test/test_Hor.jpy'
    return file_path#返回新生成图片的绝对路径

# 水平翻转
def horizontalFlip(file_abs_path):
    middle_name = 'Hor'
    new_file_path = modify_file_path(file_abs_path, middle_name)
    (filename, extension)  = os.path.splitext(file_abs_path)
    extension = extension.upper().split('.')[-1]
    img = Image.open(file_abs_path).convert('RGB')
    img.transpose(Image.FLIP_LEFT_RIGHT).save(new_file_path)#进行转化，并且保存图片（以下同）
    return new_file_path


# 垂直翻转
def verticalFlip(file_abs_path):
    middle_name = 'Ver'
    new_file_path = modify_file_path(file_abs_path, middle_name)
    (filename, extension)  = os.path.splitext(file_abs_path)
    extension = extension.upper().split('.')[-1]
    img = Image.open(file_abs_path).convert('RGB')
    img.transpose(Image.FLIP_TOP_BOTTOM).save(new_file_path)
    return new_file_path

# 旋转角度
def rotate(file_abs_path, rotate_angle):
    if rotate_angle >= -45 and rotate_angle <= 45:
        i_randint = rotate_angle
    else:
        i_randint = random.randint(-45, 45)
    middle_name = 'Rotate%d' % (i_randint)
    new_file_path = modify_file_path(file_abs_path, middle_name)
    (filename, extension)  = os.path.splitext(file_abs_path)
    extension = extension.upper().split('.')[-1]
    img = Image.open(file_abs_path).convert('RGB')
    img.rotate(i_randint).save(new_file_path)
    return new_file_path

# 图像裁剪
def ImgCrop(file_abs_path, top_ws, top_hs, widths, heights):
    #(top_w, top_h):左上角定点
    #(width, height):裁剪大小
    middle_name = 'Crop'
    new_file_path = modify_file_path(file_abs_path, middle_name)
    (filename, extension)  = os.path.splitext(file_abs_path)
    extension = extension.upper().split('.')[-1]
      
    img = Image.open(file_abs_path).convert('RGB')
    width, height = img.size

    crop_img = (top_ws*width, top_hs*height, top_ws*width + widths*width, top_hs*height + heights*height)
    im_RCrops = img.crop(crop_img)
    im_RCrops.save(new_file_path)
    return new_file_path

# 随机裁剪
def randCrop(file_abs_path):
    i_randint = random.randint(1, 10)
    middle_name = 'RandCrop_%d' % (i_randint)
    new_file_path = modify_file_path(file_abs_path, middle_name)

    (filename, extension)  = os.path.splitext(file_abs_path)
    extension = extension.upper().split('.')[-1]
    img = Image.open(file_abs_path).convert('RGB')
    width, height = img.size
    # print(width, height)
    ratio = 0.88  # 0.8--0.9之间的一个数字
    left = int(width * (1 - ratio) * random.random())  # 左上角点的横坐标
    top = int(height * (1 - ratio) * random.random())  # 左上角点的纵坐标

    crop_img = (left, top, left + width * ratio, top + height * ratio)
    im_RCrops = img.crop(crop_img)
    im_RCrops.save(new_file_path)
    return new_file_path


# 色彩抖动相关，基本都是滤波
def jittering(file_abs_path, jitterring_type=0):
    (filename, extension)  = os.path.splitext(file_abs_path)
    extension = extension.upper().split('.')[-1]
    img = Image.open(file_abs_path).convert('RGB')
    jitterring_type = int(jitterring_type)
    if jitterring_type >= 1 and jitterring_type <= 9:
        i_randint = jitterring_type
    else:
        i_randint = random.randint(1, 9)
    if i_randint == 1:
        # 高斯模糊
        middle_name = 'Jittering_%s' % ('GaussianBlur')
        new_file_path = modify_file_path(file_abs_path, middle_name)
        img.filter(ImageFilter.GaussianBlur).save(new_file_path)
    elif i_randint == 2:
        # 普通模糊
        middle_name = 'Jittering_%s' % ('BLUR')
        new_file_path = modify_file_path(file_abs_path, middle_name)
        img.filter(ImageFilter.BLUR).save(new_file_path)
    elif i_randint == 3:
        # 边缘增强
        middle_name = 'Jittering_%s' % ('EDGE_ENHANCE')
        new_file_path = modify_file_path(file_abs_path, middle_name)
        img.filter(ImageFilter.EDGE_ENHANCE).save(new_file_path)
    elif i_randint == 4:
        # 找到边缘
        middle_name = 'Jittering_%s' % ('FIND_EDGES')
        new_file_path = modify_file_path(file_abs_path, middle_name)
        img.filter(ImageFilter.FIND_EDGES).save(new_file_path)
    elif i_randint == 5:
        # 浮雕
        middle_name = 'Jittering_%s' % ('EMBOSS')
        new_file_path = modify_file_path(file_abs_path, middle_name)
        img.filter(ImageFilter.EMBOSS).save(new_file_path)
    elif i_randint == 6:
        # 轮廓
        middle_name = 'Jittering_%s' % ('CONTOUR')
        new_file_path = modify_file_path(file_abs_path, middle_name)
        img.filter(ImageFilter.CONTOUR).save(new_file_path)
    elif i_randint == 7:
        # 锐化
        middle_name = 'Jittering_%s' % ('SHARPEN')
        new_file_path = modify_file_path(file_abs_path, middle_name)
        img.filter(ImageFilter.SHARPEN).save(new_file_path)
    elif i_randint == 8:
        # 平滑
        middle_name = 'Jittering_%s' % ('SMOOTH')
        new_file_path = modify_file_path(file_abs_path, middle_name)
        img.filter(ImageFilter.SMOOTH).save(new_file_path)
    else:
        # 细节
        middle_name = 'Jittering_%s' % ('DETAIL')
        new_file_path = modify_file_path(file_abs_path, middle_name)
        img.filter(ImageFilter.DETAIL).save(new_file_path)

    return new_file_path



DataPath = 'G:/ChiYuTing/data/train'
Classnames = ['1','2','3']

for c_name in Classnames:
    c_path = DataPath + '/'+ c_name
    all_img_name = os.listdir(c_path)
    for img_name in all_img_name:
        img_path = os.path.join(c_path, img_name)
        print(img_path)
        
        #示例1:
        #ImgCrop(img_path, 0.219, 0.324, 0.55, 0.55) # 因为我们图大小不一致，所以取百分比
        # (四个值为左上定点和裁剪的长宽)
        
        #示例2:
        #horizontalFlip(img_path)
        break
    
    